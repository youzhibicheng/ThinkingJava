import java.util.*;                  // Provides TreeMap and Iterator
public class ZeroDivision
{
     public static void main(String[ ] args)
     {
        // Just to show the result of a division by zero.
        double one = 1.0;
        double zero = 0.0;
        System.out.println(one/zero);
     }
}
